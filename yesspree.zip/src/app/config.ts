export class AppSettings {
    //mainserverurl: http://192.169.243.70:5000/
    public static baseUrl = 'http://13.251.141.190/yespree/api/';
    public static imageUrl = 'http://13.251.141.190/yespree/';
    // public static localUrl = 'http://192.168.0.136:3000/';
    // public static baseUrl = 'http://192.168.0.130:3000/';

}
