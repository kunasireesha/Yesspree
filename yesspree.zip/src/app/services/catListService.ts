
import { catList } from './catList';

export class CatListServices {
    public categories: catList;

}

