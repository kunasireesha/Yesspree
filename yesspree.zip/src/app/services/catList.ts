export class catList {
    cat_Id: any;
}
export class ForSocial{
    
}